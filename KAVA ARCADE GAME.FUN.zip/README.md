# Neon Arcade — Vercel Ready

Website mini-game publik yang dapat langsung dideploy ke Vercel.

## Deploy paling mudah
1. Buat akun GitHub dan Vercel.
2. Buat repository baru di GitHub.
3. Upload semua isi folder ini ke repository.
4. Di Vercel pilih **Add New → Project**.
5. Pilih repository tersebut.
6. Klik **Deploy**.
7. Vercel akan memberikan URL `*.vercel.app`.

Tidak perlu build command atau database untuk versi awal ini.

## Catatan
- Game berjalan di browser.
- Leaderboard pada versi ini masih lokal di browser (`localStorage`).
- Untuk leaderboard global, akun pemain, anti-cheat skor, dan database online, tambahkan Supabase/backend pada tahap berikutnya.
- Desain dan nama project ini adalah konsep orisinal dan bukan situs resmi pihak lain.
